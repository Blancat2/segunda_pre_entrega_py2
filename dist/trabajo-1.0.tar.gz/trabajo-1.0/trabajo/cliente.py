
class Cliente: 

   
    def __init__ (self, nombre, mail, edad):
        self.nombre = input("Ingrese nombre del cliente")
        self.mail = input("Ingrese mail del Cliente")
        self.edad = input("Ingrese edad del cliente")
        self.lista_datos = []

   
    
    def agregar_datos(self, nombre, mail, edad):
        datos = Cliente(nombre, mail, edad)
        self.lista_datos.append(datos)

    
    def mostrar_cliente(self):
        print(f"El usuario de {self.nombre} se ha creado")
    
    def __str__(self):
        print(self.mostrar_cliente)
