from setuptools import setup

setup (
    name= "trabajo",
    version= "1.0",
    description="Segunda Pre Entrega",
    author="Agustin Blancat",
    author_email="agustin@gmail.com",
    packages=["trabajo"]


)